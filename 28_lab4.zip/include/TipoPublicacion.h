#ifndef TIPOPUBLICACION_H
#define TIPOPUBLICACION_H

enum TipoPublicacion {
    Venta,
    Alquiler
};

#endif