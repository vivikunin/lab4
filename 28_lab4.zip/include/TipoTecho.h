#ifndef TIPOTECHO_H
#define TIPOTECHO_H

enum TipoTecho {
    Liviano,
    A_dos_aguas,
    Plano
};

#endif